package uts1_225314067;

public class tes {
    public static void main(String[] args) {
        BinaryTree a = new BinaryTree();
        int arr[] = {100,150,50,10,60,110,160};
        for (int i : arr) {
            a.insert(i);
        }
            System.out.println(a.sesuatu(150));
    }
}
